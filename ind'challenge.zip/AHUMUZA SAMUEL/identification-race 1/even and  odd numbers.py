def main(): 
    print("Welcome to the Indentation Race!")
for i in range(5): 
    print(f"Current number: {i}") 
if i % 2 == 0: 
    print("Even number.",) 
else:
    print("Odd number.",)
    print("Race completed!") 
 
main() 